package Exercicio3;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        int escolha = 0;

        Restaurante r = new Restaurante();
        Mesa m = new Mesa();
        Conta c = new Conta();

        r.adicionarPrato("Escondidinho", 15);
        r.adicionarPrato("Batata Frita", 23);
        r.adicionarPrato("Lasanha de Berinjela", 20);

        m.setGarcom("Daniel");
        m.setConta(c);
        m.setAberta(true);

        r.adicionarMesa(m);

        c.adicionarPedido("Strogonoff", 15, 1);
        c.adicionarPedido("Batata Frita", 23, 1);
        c.adicionarPedido("Lasanha de Berinjela", 20, 1);
        do {
            System.out.println(
                    "1 - Buscar prato;\n2 - Verificar disponibilidade de mesa;\n3 - Solicitar conta;\n4 - Sair.");
            escolha = entrada.nextInt();

            switch (escolha) {
                case 1:
                r.pesquisarPrato("Prato 1");
                    break;
                case 2:
                r.mesaIsDisponivel(m);
                    
                    break;
                case 3:
                r.solicitarConta(m);
                    break;
            }
            
        } while (escolha != 4);
        if(escolha==4){
            System.out.println("\nObrigada pela Preferência!");
        }
        entrada.close();
    }
}